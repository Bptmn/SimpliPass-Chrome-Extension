export const radius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 20,
  xl: 30,
  pill: 999,
} as const;

export type RadiusKey = keyof typeof radius; 