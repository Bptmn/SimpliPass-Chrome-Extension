export const shadow = {
  card: '0 2px 8px rgba(0,0,0,0.04)',
  cardHover: '0 4px 16px rgba(26,115,232,0.10)',
} as const;

export type ShadowKey = keyof typeof shadow; 