export const layout = {
  navbarHeight: 60,
  helperBarHeight: 60,
  primaryBackground: '#ffffff',
  secondaryBackground: '#f1f4f8',
  sectionSpacing: 15,
} as const;

export type LayoutKey = keyof typeof layout; 