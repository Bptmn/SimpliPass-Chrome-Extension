export const spacing = {
  xxs: 2,
  xs: 4,
  sm: 7,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
} as const;

export type SpacingKey = keyof typeof spacing; 