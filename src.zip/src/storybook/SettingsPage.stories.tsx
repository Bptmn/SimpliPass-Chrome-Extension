import React from 'react';
import SettingsPage from '../popup/pages/SettingsPage';

export default {
  title: 'Pages/SettingsPage',
  component: SettingsPage,
};

export const Default = () => <SettingsPage />; 