import React from 'react';
import { GeneratorPage } from '../popup/pages/GeneratorPage';

export default {
  title: 'Pages/GeneratorPage',
  component: GeneratorPage,
};

export const Default = () => <GeneratorPage />; 