import React from 'react';
import { View, StyleSheet } from 'react-native';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

export const SkeletonCard: React.FC = () => (
  <View style={styles.skeletonCard}>
    <View style={styles.skeletonAvatar} />
    <View style={styles.skeletonInfo}>
      <View style={styles.skeletonTitle} />
      <View style={styles.skeletonUsername} />
    </View>
  </View>
);

const styles = StyleSheet.create({
  skeletonCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: layout.secondaryBackground,
    borderRadius: radius.lg,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 6,
    marginBottom: spacing.xs,
  },
  skeletonAvatar: {
    width: 35,
    height: 35,
    borderRadius: 10,
    backgroundColor: colors.disabled,
    marginRight: spacing.sm,
  },
  skeletonInfo: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: spacing.xs,
  },
  skeletonTitle: {
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.disabled,
    width: '60%',
    marginBottom: spacing.xs,
  },
  skeletonUsername: {
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.disabled,
    width: '40%',
  },
});

export default SkeletonCard;
