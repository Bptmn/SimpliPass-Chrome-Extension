import React from 'react';
import { View, Text, Pressable, StyleSheet, Alert } from 'react-native';
import { Icon } from './Icon';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { radius } from '../../design/radius';
import { typography } from '../../design/typography';

interface CopyButtonProps {
  textToCopy: string;
  ariaLabel?: string;
  children?: React.ReactNode;
  onClick?: () => void;
}

const CopyButton: React.FC<CopyButtonProps> = ({ textToCopy, ariaLabel = 'Copier', children, onClick }) => {
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(textToCopy);
      if (onClick) onClick();
      // Optionally, show a feedback (can be improved)
      Alert.alert('Copié !');
    } catch (e) {
      Alert.alert('Erreur lors de la copie');
    }
  };

  return (
    <Pressable
      style={styles.button}
      onPress={handleCopy}
      accessibilityLabel={ariaLabel}
      accessibilityRole="button"
    >
      <View style={styles.container}>
        <Icon name="copy" size={25} color={'white'} />
        <Text style={styles.text}>{children || 'copier'}</Text>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  button: {
    width: 42,
    height: 38,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
    padding: spacing.xs,
    color: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.secondary,
  },
  container: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xxs,
    width: '100%',
    height: '100%',
  },
  text: {
    fontSize: typography.fontSize.xs,
    lineHeight: 1,
    color: colors.white,
  },
});

export default CopyButton; 