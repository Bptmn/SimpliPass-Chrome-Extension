import React, { useState, useCallback, useContext, createContext, ReactNode } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../../design/colors';
import { radius } from '../../design/radius';
import { typography } from '../../design/typography';
import { spacing } from '../../design/spacing';
import { Icon } from './Icon';

export const Toast: React.FC<{ message: string }> = ({ message }) => (
  <View
    style={[styles.toast, message ? styles.toastShow : null]}
    accessibilityRole="alert"
    accessibilityLiveRegion="polite"
    pointerEvents={message ? 'auto' : 'none'}
  >
    <Icon name="checkCircle" size={20} color={colors.secondary} />
    <Text style={styles.toastText}>{message}</Text>
  </View>
);

// Toast Context
interface ToastContextType {
  toast: string;
  showToast: (msg: string) => void;
}
const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toast, setToast] = useState('');
  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2000);
  }, []);
  return (
    <ToastContext.Provider value={{ toast, showToast }}>
      {children}
      <Toast message={toast} />
    </ToastContext.Provider>
  );
};

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within a ToastProvider');
  return ctx;
}

const styles = StyleSheet.create({
  toast: {
    position: 'absolute',
    bottom: 32,
    left: 0,
    right: 0,
    marginLeft: 'auto',
    marginRight: 'auto',
    backgroundColor: colors.white,
    color: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.secondary,
    opacity: 0,
    zIndex: 9999,
    fontSize: typography.fontSize.sm,
    fontWeight: '400',
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 120,
    maxWidth: 320,
    alignSelf: 'center',
  },
  toastShow: {
    opacity: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: spacing.sm,
  },
  toastText: {
    color: colors.primary,
    fontSize: typography.fontSize.sm,
    fontWeight: '400',
    marginLeft: spacing.sm,
  },
});

export default Toast;
