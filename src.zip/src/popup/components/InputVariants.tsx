import React from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { IconKey } from 'utils/icon';

// --- Input classique ---
export interface InputProps {
  label: string;
  id: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  autoComplete?: string;
  required?: boolean;
  error?: string;
  disabled?: boolean;
}

export const Input: React.FC<InputProps> = ({
  label,
  id,
  value,
  onChange,
  placeholder,
  type = 'text',
  autoComplete,
  required = false,
  error,
  disabled = false,
}) => (
  <View style={styles.formSection}>
    <Text style={styles.inputLabel}>{label}</Text>
    <TextInput
      style={[
        styles.input,
        error ? styles.inputError : null,
        disabled ? styles.inputDisabled : null,
      ]}
      value={value}
      onChangeText={onChange}
      placeholder={placeholder}
      editable={!disabled}
      autoComplete={autoComplete as any}
      secureTextEntry={type === 'password'}
      accessibilityLabel={label}
    />
    {error ? <Text style={styles.inputErrorMessage}>{error}</Text> : null}
  </View>
);

// --- InputPasswordGenerator ---
export interface InputPasswordGeneratorProps {
  label: string;
  id: string;
  value: string;
  onChange: (value: string) => void;
  onGenerate: () => void;
  placeholder?: string;
  required?: boolean;
  passwordStrength?: string;
  onAdvancedOptions?: () => void;
  Icon?: React.ComponentType<{ name: IconKey; size?: number; color?: string }>;
  error?: string;
}

export const InputPasswordGenerator: React.FC<InputPasswordGeneratorProps> = ({
  label,
  id,
  value,
  onChange,
  onGenerate,
  placeholder = 'Entrez un mot de passe...',
  required = false,
  passwordStrength,
  onAdvancedOptions,
  Icon,
  error,
}) => (
  <View style={styles.formSection}>
    <View style={styles.passwordStrengthContainer}>
      <Text style={styles.inputLabel}>{label}</Text>
      {passwordStrength && (
        <View style={styles.passwordStrength}>
          <Text>{passwordStrength} </Text>
          {Icon && <Icon name="security" size={18} color={colors.success} />}
        </View>
      )}
    </View>
    <TextInput
      style={[
        styles.input,
        error ? styles.inputError : null,
      ]}
      value={value}
      onChangeText={onChange}
      placeholder={placeholder}
      accessibilityLabel={label}
    />
    {error ? <Text style={styles.inputErrorMessage}>{error}</Text> : null}
    <View style={styles.flexEnd}>
      <Pressable style={styles.generateBtn} onPress={onGenerate} accessibilityRole="button">
        <Text style={styles.generateBtnText}>Générer un mot de passe</Text>
      </Pressable>
    </View>
  </View>
);

const styles = StyleSheet.create({
  formSection: {
    flexDirection: 'column',
    marginBottom: spacing.md,
  },
  inputLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: '500',
    color: colors.primary,
    marginBottom: 2,
  },
  input: {
    width: '100%',
    height: 48,
    backgroundColor: colors.bgAlt,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.xl,
    paddingHorizontal: spacing.md,
    fontSize: typography.fontSize.sm,
    color: colors.text,
    fontWeight: '500',
    marginBottom: 2,
  },
  inputError: {
    borderColor: colors.error,
  },
  inputDisabled: {
    backgroundColor: colors.disabled,
    color: colors.textSecondary,
  },
  inputErrorMessage: {
    color: colors.error,
    fontSize: typography.fontSize.sm,
    fontWeight: '500',
    marginTop: 2,
  },
  passwordStrengthContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  passwordStrength: {
    flexDirection: 'row',
    alignItems: 'center',
    // gap: spacing.xs,
    // Instead of gap, use marginRight on the first child if needed
  },
  flexEnd: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  generateBtn: {
    backgroundColor: colors.secondary,
    borderRadius: radius.lg,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  generateBtnText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: typography.fontSize.sm,
  },
}); 