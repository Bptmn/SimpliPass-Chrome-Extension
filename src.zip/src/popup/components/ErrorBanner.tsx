import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../../design/colors';
import { radius } from '../../design/radius';

interface ErrorBannerProps {
  message: string;
}

export const ErrorBanner: React.FC<ErrorBannerProps> = ({ message }) => (
  <View style={styles.errorBanner} accessibilityRole="alert" accessibilityLiveRegion="assertive">
    <Text style={styles.errorTitle}>Erreur</Text>
    <Text style={styles.errorText}>{message}</Text>
  </View>
);

const styles = StyleSheet.create({
  errorBanner: {
    padding: 20,
    margin: 20,
    borderWidth: 1,
    borderColor: colors.error,
    borderRadius: radius.md,
    backgroundColor: colors.bg,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
  },
  errorTitle: {
    color: colors.error,
    marginBottom: 15,
    fontSize: 18,
    fontWeight: '600',
  },
  errorText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
});
