// HelperBar.tsx
// This component renders the bottom helper bar in the popup UI, providing quick access to add credentials, FAQ, and refresh actions.
// Responsibilities:
// - Render helper bar with action buttons
// - Handle navigation and refresh logic
// - Use the shared Icon component for button icons

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { View, Text, Pressable, StyleSheet } from 'react-native';

import { Icon } from './Icon';
import { refreshCredentialsInVaultDb } from 'logic/items';
import { auth } from 'services/firebase';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';
import { typography } from '../../design/typography';

export const HelperBar: React.FC = () => {
  const navigate = useNavigate();

  // Handler for the add credential button
  const handleAddCredential = () => {
    navigate('/add-credential');
  };

  // Handler for the FAQ button
  const handleFAQ = () => {
    // TODO: Implement FAQ navigation
    console.log('FAQ clicked');
  };

  // Handler for the refresh button (uses business logic)
  const handleRefresh = async () => {
    if (auth.currentUser) {
      await refreshCredentialsInVaultDb(auth.currentUser);
      window.location.reload();
    } else {
      console.log('No user logged in, cannot refresh cache');
    }
  };

  return (
    <View style={styles.helperBar}>
      <View style={styles.helperBarLeft}>
        <Pressable
          style={styles.helperBtn}
          onPress={handleAddCredential}
          accessibilityRole="button"
          accessibilityLabel="Ajouter un identifiant"
        >
          <Icon name="add" size={25} color={colors.primary} />
          <Text style={styles.helperBtnText}>Ajouter</Text>
        </Pressable>
      </View>
      <View style={styles.helperBarRight}>
        <Pressable
          style={styles.helperBtn}
          onPress={handleFAQ}
          accessibilityRole="button"
          accessibilityLabel="Aide"
        >
          <Icon name="help" size={25} color={colors.primary} />
          <Text style={styles.helperBtnText}>Aide</Text>
        </Pressable>
        <Pressable
          style={styles.helperBtn}
          onPress={handleRefresh}
          accessibilityRole="button"
          accessibilityLabel="Actualiser les identifiants"
        >
          <Icon name="refresh" size={25} color={colors.primary} />
          <Text style={styles.helperBtnText}>Actualiser</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  helperBar: {
    width: '100%',
    height: layout.helperBarHeight,
    backgroundColor: layout.primaryBackground,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.sm,
  },
  helperBarLeft: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  helperBarRight: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginLeft: spacing.xl,
  },
  helperBtn: {
    backgroundColor: 'transparent',
    borderWidth: 0,
    width: 48,
    height: 40,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.sm,
    marginRight: spacing.md,
  },
  helperBtnText: {
    fontSize: typography.fontSize.xs * 0.75,
    color: colors.text,
    textAlign: 'center',
    width: '100%',
    marginTop: spacing.xxs,
  },
});
