// CredentialCard.tsx
// This component displays a single credential (title, username, icon) and provides a copy-to-clipboard button for the password.
// Used in both the popup and popover for credential display and interaction.

import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { CredentialFromVaultDb } from 'types/types';
import { decryptData } from 'utils/crypto';
import { getUserSecretKey } from 'logic/user';
import CopyButton from './CopyButton';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { radius } from '../../design/radius';
import { typography } from '../../design/typography';

// Minimal RN-compatible LazyCredentialIcon
const LazyCredentialIcon: React.FC<{ title: string; url?: string }> = ({ title }) => (
  <View style={styles.iconContainer}>
    <Text style={styles.iconLetter}>{title ? title[0].toUpperCase() : '?'}</Text>
  </View>
);

// Minimal RN-compatible ErrorBanner
const ErrorBanner: React.FC<{ message: string }> = ({ message }) => (
  <View style={styles.errorBanner} accessibilityRole="alert" accessibilityLiveRegion="assertive">
    <Text style={styles.errorTitle}>Erreur</Text>
    <Text style={styles.errorText}>{message}</Text>
  </View>
);

interface CredentialCardProps {
  cred: CredentialFromVaultDb;
  onClick?: () => void;
  hideCopyBtn?: boolean;
  onCopy?: () => void;
}

export const CredentialCard: React.FC<CredentialCardProps> = React.memo(({
  cred,
  onClick,
  hideCopyBtn,
  onCopy,
}) => {
  const [error, setError] = React.useState<string | null>(null);

  // Handles copying the password to clipboard
  const handleCopy = async () => {
    try {
      const userSecretKey = await getUserSecretKey();
      if (!userSecretKey) throw new Error('User secret key not found');
      const itemKey = await decryptData(userSecretKey, cred.itemKeyCipher);
      const password = await decryptData(itemKey, cred.passwordCipher);
      await navigator.clipboard.writeText(password);
      if (onCopy) onCopy();
    } catch (e) {
      setError('Erreur lors de la copie du mot de passe.');
    }
  };

  return (
    <>
      {error && <ErrorBanner message={error} />}
      <Pressable
        style={styles.card}
        onPress={onClick}
        accessibilityLabel={`Credential for ${cred.title} (${cred.username})`}
        accessibilityRole="button"
      >
        <View style={styles.cardLeft}>
          <LazyCredentialIcon title={cred.title || ''} url={cred.url} />
          <View style={styles.cardInfo}>
            <Text style={styles.cardTitle}>{cred.title || 'Title'}</Text>
            <Text style={styles.cardUsername}>{cred.username || ''}</Text>
          </View>
        </View>
        {!hideCopyBtn && (
          <CopyButton textToCopy={''} onClick={handleCopy} />
        )}
      </Pressable>
    </>
  );
});

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.secondary,
    borderRadius: radius.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 6,
    justifyContent: 'space-between',
    marginBottom: spacing.xs,
  },
  cardLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconContainer: {
    width: 35,
    height: 35,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconLetter: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.accent,
    textAlign: 'center',
    width: '100%',
    lineHeight: 35,
  },
  cardInfo: {
    flexDirection: 'column',
    gap: 2,
    maxWidth: 200,
    minWidth: 0,
  },
  cardTitle: {
    fontWeight: '600',
    fontSize: 15,
    color: colors.primary,
    flexShrink: 1,
  },
  cardUsername: {
    fontSize: 12,
    color: colors.textSecondary,
    flexShrink: 1,
  },
  errorBanner: {
    padding: 20,
    margin: 20,
    borderWidth: 1,
    borderColor: colors.error,
    borderRadius: radius.md,
    backgroundColor: colors.bg,
    shadowColor: '#000',
    shadowOpacity: 0.04,
    shadowRadius: 8,
  },
  errorTitle: {
    color: colors.error,
    marginBottom: 15,
    fontSize: 18,
    fontWeight: '600',
  },
  errorText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
});
