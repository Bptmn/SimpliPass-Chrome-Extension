import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { View, Text, Pressable, StyleSheet } from 'react-native';

import { Icon } from './Icon';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { layout } from '../../design/layout';

interface NavItem {
  path: string;
  icon: React.ReactNode;
  label: string;
}

const navItems: NavItem[] = [
  {
    path: '/home',
    icon: <Icon name="home" size={25} color={colors.primary} />,
    label: 'Accueil',
  },
  {
    path: '/generator',
    icon: <Icon name="loop" size={25} color={colors.primary} />,
    label: 'Générateur',
  },
  {
    path: '/settings',
    icon: <Icon name="settings" size={25} color={colors.primary} />,
    label: 'Paramètres',
  },
];

const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <View style={styles.navbar}>
      {navItems.map((item) => (
        <Pressable
          key={item.path}
          style={[
            styles.navItem,
            location.pathname === item.path ? styles.active : null,
          ]}
          onPress={() => navigate(item.path)}
          accessibilityRole="button"
          accessibilityLabel={item.label}
        >
          <View style={styles.navContent}>
            {item.icon}
            <Text style={[
              styles.navLabel,
              location.pathname === item.path ? { color: colors.primary } : null,
            ]}>
              {item.label}
            </Text>
          </View>
        </Pressable>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  navbar: {
    width: '100%',
    height: layout.navbarHeight,
    minHeight: layout.navbarHeight,
    maxHeight: layout.navbarHeight,
    backgroundColor: layout.primaryBackground,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    zIndex: 1000,
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  navItem: {
    flex: 1,
    height: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    borderWidth: 0,
    padding: 0,
  },
  active: {
    // Color will be applied to text elements
  },
  navContent: {
    flexDirection: 'column',
    alignItems: 'center',
    marginBottom: spacing.xxs,
  },
  navLabel: {
    fontSize: typography.fontSize.xs,
    fontWeight: '500',
    fontFamily: typography.fontFamily.base,
    color: colors.accent,
    marginTop: spacing.xxs,
  },
});

export default Navbar;
