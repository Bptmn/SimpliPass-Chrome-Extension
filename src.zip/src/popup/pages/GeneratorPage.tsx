import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';

import { checkPasswordStrength } from 'utils/checkPasswordStrength';
import { passwordGenerator } from 'utils/passwordGenerator';
import { useToast } from '../components/Toast';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

export const GeneratorPage: React.FC = () => {
  const [hasUppercase, setHasUppercase] = useState(true);
  const [hasNumbers, setHasNumbers] = useState(true);
  const [hasLowercase] = useState(true); // Always true as in Flutter code
  const [hasSpecialCharacters, setHasSpecialCharacters] = useState(true);
  const [passwordWidth, setPasswordWidth] = useState(12);
  const [generatedPassword, setGeneratedPassword] = useState('');
  const [passwordStrength, setPasswordStrength] = useState<
    'weak' | 'average' | 'strong' | 'perfect'
  >('weak');
  const { showToast } = useToast();

  // Generate password and check strength on mount and whenever options change
  useEffect(() => {
    const pwd = passwordGenerator(
      hasNumbers,
      hasUppercase,
      hasLowercase,
      hasSpecialCharacters,
      passwordWidth,
    );
    setGeneratedPassword(pwd);
    setPasswordStrength(checkPasswordStrength(pwd));
  }, [hasNumbers, hasUppercase, hasLowercase, hasSpecialCharacters, passwordWidth]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(generatedPassword);
    showToast('Mot de passe copié !');
  };

  const handleRegenerate = () => {
    const pwd = passwordGenerator(
      hasNumbers,
      hasUppercase,
      hasLowercase,
      hasSpecialCharacters,
      passwordWidth,
    );
    setGeneratedPassword(pwd);
    setPasswordStrength(checkPasswordStrength(pwd));
  };

  return (
    <View style={styles.pageContainer}>
      <View style={styles.generatorContent}>
        <View style={styles.generatorForm}>
          <View style={styles.generatorItemSpacing}>
            <Text style={styles.sectionLabel}>Mot de passe</Text>
            <View style={styles.generatedPasswordCard}>
              <View style={styles.passwordDisplay}>
                <Text style={styles.passwordText}>{generatedPassword}</Text>
                <Pressable
                  style={styles.btnCopy}
                  onPress={handleCopy}
                  accessibilityLabel="Copy password for this credential"
                >
                  <View style={styles.btnCopyContainer}>
                    <Text style={styles.copyIcon}>📋</Text>
                    <Text style={styles.copyText}>copier</Text>
                  </View>
                </Pressable>
              </View>
              <Text style={[
                styles.strengthLabel,
                passwordStrength === 'weak' ? styles.strengthWeak :
                passwordStrength === 'average' ? styles.strengthAverage :
                passwordStrength === 'strong' ? styles.strengthStrong :
                styles.strengthPerfect
              ]}>
                Sécurité :{' '}
                {passwordStrength === 'weak'
                  ? 'faible'
                  : passwordStrength === 'average'
                    ? 'moyenne'
                    : passwordStrength === 'perfect'
                      ? 'parfaite !'
                      : 'forte'}
              </Text>
            </View>
          </View>

          <View style={styles.generatorItemSpacing}>
            <Text style={styles.sectionLabel}>Longueur : {passwordWidth}</Text>
            <View style={styles.sliderSection}>
              <Text style={styles.sliderText}>Slider component would go here</Text>
            </View>
          </View>

          <View style={styles.generatorItemSpacing}>
            <Text style={styles.sectionLabel}>Options</Text>
            <View style={styles.optionsSection}>
              <View style={styles.optionRow}>
                <Text style={styles.optionText}>Lettres majuscules (A-Z)</Text>
                <Pressable
                  style={[styles.switch, hasUppercase ? styles.switchActive : null]}
                  onPress={() => setHasUppercase(!hasUppercase)}
                >
                  <View style={[styles.switchSlider, hasUppercase ? styles.switchSliderActive : null]} />
                </Pressable>
              </View>
              <View style={styles.optionRow}>
                <Text style={styles.optionText}>Chiffres (0-9)</Text>
                <Pressable
                  style={[styles.switch, hasNumbers ? styles.switchActive : null]}
                  onPress={() => setHasNumbers(!hasNumbers)}
                >
                  <View style={[styles.switchSlider, hasNumbers ? styles.switchSliderActive : null]} />
                </Pressable>
              </View>
              <View style={styles.optionRow}>
                <Text style={styles.optionText}>Symboles (@!&*)</Text>
                <Pressable
                  style={[styles.switch, hasSpecialCharacters ? styles.switchActive : null]}
                  onPress={() => setHasSpecialCharacters(!hasSpecialCharacters)}
                >
                  <View style={[styles.switchSlider, hasSpecialCharacters ? styles.switchSliderActive : null]} />
                </Pressable>
              </View>
            </View>
          </View>

          <View style={styles.pageSection}>
            <Pressable style={[styles.btn, styles.btnPrimary, styles.regenerateBtn]} onPress={handleRegenerate}>
              <Text style={styles.regenerateIcon}>🔄</Text>
              <Text style={styles.btnText}>Générer à nouveau</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    padding: spacing.md,
  },
  generatorContent: {
    flex: 1,
  },
  generatorForm: {
    flexDirection: 'column',
    marginBottom: spacing.md,
  },
  generatorItemSpacing: {
    marginBottom: spacing.sm,
  },
  sectionLabel: {
    fontSize: typography.fontSize.xs,
    color: colors.accent,
    fontWeight: '500',
    margin: 0,
  },
  generatedPasswordCard: {
    flexDirection: 'column',
    marginBottom: spacing.sm,
    padding: spacing.md,
    backgroundColor: layout.secondaryBackground,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  passwordDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  passwordText: {
    flex: 1,
    fontSize: typography.fontSize.md,
    color: colors.text,
    fontFamily: 'Monaco, Menlo, Ubuntu Mono, monospace',
    backgroundColor: layout.primaryBackground,
    padding: spacing.sm,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    minHeight: 20,
  },
  strengthLabel: {
    fontSize: typography.fontSize.sm,
    fontWeight: '500',
    flexDirection: 'row',
    alignItems: 'center',
  },
  strengthWeak: { color: '#e57373' },
  strengthAverage: { color: '#ffb300' },
  strengthStrong: { color: colors.primary },
  strengthPerfect: { color: colors.secondary },
  btnCopy: {
    width: 42,
    height: 38,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xs,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    backgroundColor: colors.secondary,
    marginLeft: spacing.sm,
  },
  btnCopyContainer: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    height: '100%',
  },
  copyIcon: {
    fontSize: 22,
    color: colors.white,
  },
  copyText: {
    fontSize: 10,
    lineHeight: 1,
    color: colors.white,
  },
  sliderSection: {
    flexDirection: 'column',
    marginBottom: spacing.sm,
    padding: spacing.md,
    backgroundColor: layout.secondaryBackground,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  sliderText: {
    fontSize: typography.fontSize.sm,
    color: colors.secondary,
    fontWeight: '500',
    margin: 0,
  },
  optionsSection: {
    flexDirection: 'column',
    marginBottom: spacing.sm,
    padding: spacing.md,
    backgroundColor: layout.secondaryBackground,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    fontSize: typography.fontSize.sm,
    color: colors.primary,
    marginBottom: spacing.sm,
  },
  optionText: {
    flex: 1,
    fontWeight: '500',
    fontSize: typography.fontSize.sm,
    color: colors.primary,
  },
  switch: {
    position: 'relative',
    width: 38,
    height: 22,
    backgroundColor: '#ccc',
    borderRadius: 22,
  },
  switchActive: {
    backgroundColor: colors.secondary,
  },
  switchSlider: {
    position: 'absolute',
    height: 18,
    width: 18,
    left: 2,
    bottom: 2,
    backgroundColor: colors.white,
    borderRadius: 9,
  },
  switchSliderActive: {
    transform: [{ translateX: 16 }],
  },
  pageSection: {
    marginBottom: spacing.md,
  },
  btn: {
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
  },
  regenerateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: '600',
  },
  regenerateIcon: {
    fontSize: 20,
    marginRight: spacing.xs,
  },
  btnText: {
    color: colors.white,
    fontSize: typography.fontSize.md,
    fontWeight: '600',
  },
});
