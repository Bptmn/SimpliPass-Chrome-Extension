import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { ErrorBanner } from '../components/ErrorBanner';
import { EmailConfirmationPage } from './EmailConfirmationPage';
import { loginUser, confirmMfa, logoutUser } from 'logic/user';
import { Input } from '../components/InputVariants';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

const REMEMBER_EMAIL_KEY = 'simplipass_remembered_email';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [rememberEmail, setRememberEmail] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [mfaStep, setMfaStep] = useState(false);
  const [mfaUser, setMfaUser] = useState<any>(null);
  const [mfaError, setMfaError] = useState('');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    // On mount, check if email is remembered
    const remembered = localStorage.getItem(REMEMBER_EMAIL_KEY);
    if (remembered) {
      setEmail(remembered);
      setRememberEmail(true);
    }
  }, []);

  useEffect(() => {
    // When rememberEmail or email changes, persist or remove
    if (rememberEmail && email) {
      localStorage.setItem(REMEMBER_EMAIL_KEY, email);
    } else if (!rememberEmail) {
      localStorage.removeItem(REMEMBER_EMAIL_KEY);
    }
  }, [rememberEmail, email]);

  // Use business logic for login
  const handleLogin = async () => {
    setEmailError('');
    setPasswordError('');
    setIsLoading(true);
    setError(null);
    let hasError = false;
    if (!email) {
      setEmailError('Email is required');
      hasError = true;
    }
    if (!password) {
      setPasswordError('Password is required');
      hasError = true;
    }
    if (hasError) {
      setIsLoading(false);
      return;
    }
    try {
      const result = await loginUser({ email, password, rememberEmail });
      if (result.mfaRequired) {
        setMfaStep(true);
        setMfaUser(result.mfaUser);
        setIsLoading(false);
      } else {
        navigate('/home');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Authentication failed.');
      setIsLoading(false);
    }
  };

  // Use business logic for MFA
  const handleMfaConfirm = async (code: string) => {
    if (!mfaUser) return;
    setIsLoading(true);
    setMfaError('');
    try {
      await confirmMfa({ code, password, mfaUser });
      navigate('/home');
    } catch (error: any) {
      setMfaError(error.message || 'Code invalide ou expiré.');
      setIsLoading(false);
    }
  };

  // Use business logic for logout
  const handleLogout = async () => {
    await logoutUser();
  };

  if (mfaStep && mfaUser) {
    return (
      <EmailConfirmationPage
        email={email}
        onConfirm={handleMfaConfirm}
        onResend={() => {}}
      />
    );
  }

  if (error) {
    return <ErrorBanner message={error} />;
  }

  return (
    <View style={styles.pageContainer}>
      <View style={styles.pageContent}>
        {/* Logo */}
        <View style={styles.loginLogo}>
          <Text style={styles.loginDot}>.</Text>
          <Text style={styles.loginSimpli}>Simpli</Text>
          <Text style={styles.loginPass}>Pass</Text>
        </View>
        <View style={styles.loginForm}>
          <View style={styles.formSection}>
            <Text style={styles.inputLabel}>Adresse email</Text>
            <View style={styles.inputWrapper}>
              <Input
                id="login-email"
                label=""
                type="email"
                placeholder="Votre adresse email…"
                autoComplete="email"
                value={email}
                onChange={setEmail}
                required
                error={emailError}
                disabled={isLoading}
              />
              {email && !isLoading && (
                <Pressable
                  style={styles.loginClearBtn}
                  onPress={() => setEmail('')}
                  accessibilityLabel="Effacer"
                >
                  <Text style={styles.clearBtnText}>×</Text>
                </Pressable>
              )}
            </View>
            {emailError ? <Text style={styles.errorMessage}>{emailError}</Text> : null}
            <View style={styles.loginCheckboxRow}>
              <Pressable
                style={styles.loginCheckboxLabel}
                onPress={() => setRememberEmail(!rememberEmail)}
                disabled={isLoading}
              >
                <View style={[
                  styles.loginCustomCheckbox,
                  rememberEmail ? styles.checkboxChecked : null,
                ]}>
                  {rememberEmail && <Text style={styles.checkboxCheckmark}>✓</Text>}
                </View>
                <Text style={styles.loginCheckboxText}>Se souvenir de mon email</Text>
              </Pressable>
            </View>
          </View>
          <View style={styles.formSection}>
            <Text style={styles.inputLabel}>Mot de passe maître</Text>
            <View style={styles.inputWrapper}>
              <Input
                id="login-password"
                label=""
                type={showPassword ? 'text' : 'password'}
                placeholder="Votre mot de passe maître.."
                autoComplete="current-password"
                value={password}
                onChange={setPassword}
                required
                error={passwordError}
                disabled={isLoading}
              />
              <Pressable
                style={styles.loginEyeBtn}
                onPress={() => setShowPassword(!showPassword)}
                disabled={isLoading}
                accessibilityLabel={showPassword ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
              >
                <Text style={styles.eyeBtnText}>
                  {showPassword ? '🙈' : '👁️'}
                </Text>
              </Pressable>
            </View>
            {passwordError ? <Text style={styles.errorMessage}>{passwordError}</Text> : null}
          </View>
          <Pressable
            style={[styles.btn, styles.btnPrimary, isLoading ? styles.btnDisabled : null]}
            onPress={handleLogin}
            disabled={isLoading}
            accessibilityRole="button"
          >
            {isLoading ? (
              <View style={styles.spinner} />
            ) : (
              <Text style={styles.btnText}>Se connecter</Text>
            )}
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  pageContent: {
    width: '100%',
    maxWidth: 360,
  },
  loginForm: {
    flexDirection: 'column',
    alignItems: 'stretch',
    marginTop: spacing.xl,
  },
  formSection: {
    flexDirection: 'column',
    alignItems: 'stretch',
    marginBottom: spacing.lg,
  },
  loginLogo: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'baseline',
    fontSize: typography.fontSize.xl,
    fontWeight: '700',
    marginBottom: spacing.xl,
  },
  loginDot: {
    color: colors.primary,
    marginRight: 2,
  },
  loginSimpli: {
    color: colors.primary,
  },
  loginPass: {
    color: colors.secondary,
  },
  inputLabel: {
    fontSize: typography.fontSize.md,
    color: colors.primary,
    fontWeight: '500',
    marginBottom: spacing.xs,
  },
  inputWrapper: {
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
  },
  loginClearBtn: {
    position: 'absolute',
    right: spacing.sm,
    top: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 0,
    paddingHorizontal: spacing.xs,
  },
  clearBtnText: {
    color: colors.accent,
    fontSize: 22,
  },
  errorMessage: {
    color: colors.error,
    fontSize: typography.fontSize.sm,
    marginTop: spacing.xs,
  },
  loginCheckboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xs,
  },
  loginCheckboxLabel: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  loginCustomCheckbox: {
    width: 14,
    height: 14,
    borderWidth: 2,
    borderColor: colors.secondary,
    borderRadius: radius.xs,
    backgroundColor: layout.primaryBackground,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxChecked: {
    backgroundColor: colors.secondary,
    borderColor: colors.secondary,
  },
  checkboxCheckmark: {
    color: layout.primaryBackground,
    fontSize: 10,
    fontWeight: 'bold',
  },
  loginCheckboxText: {
    fontSize: typography.fontSize.sm,
    color: colors.secondary,
    marginLeft: spacing.xs,
    fontWeight: '500',
  },
  loginEyeBtn: {
    position: 'absolute',
    right: spacing.sm,
    top: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 0,
    paddingHorizontal: spacing.xs,
  },
  eyeBtnText: {
    color: colors.accent,
    fontSize: 20,
  },
  btn: {
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
  },
  btnDisabled: {
    backgroundColor: colors.disabled,
  },
  btnText: {
    color: colors.white,
    fontSize: typography.fontSize.md,
    fontWeight: '600',
  },
  spinner: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: colors.white,
    borderTopColor: 'transparent',
  },
});

export default LoginPage;
