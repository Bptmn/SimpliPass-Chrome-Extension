import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { CredentialDecrypted } from 'types/types';
import { updateCredential } from 'logic/items';
import { ErrorBanner } from '../components/ErrorBanner';
import { Icon } from '../components/Icon';
import { Toast, useToast } from '../components/Toast';
import { Input } from '../components/InputVariants';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

export const ModifyCredentialPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const credential = location.state?.credential as CredentialDecrypted;
  
  const [title, setTitle] = useState(credential?.title || '');
  const [username, setUsername] = useState(credential?.username || '');
  const [password, setPassword] = useState(credential?.password || '');
  const [url, setUrl] = useState(credential?.url || '');
  const [note, setNote] = useState(credential?.note || '');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast, showToast } = useToast();

  useEffect(() => {
    if (!credential) {
      navigate('/');
    }
  }, [credential, navigate]);

  const handleSubmit = async () => {
    if (!credential) return;
    
    setLoading(true);
    setError(null);
    try {
      const updatedCredential: CredentialDecrypted = {
        ...credential,
        title,
        username,
        password,
        url,
        note,
        lastUseDateTime: new Date(),
      };
      await updateCredential(credential.title, updatedCredential);
      showToast('Identifiant modifié avec succès');
      setTimeout(() => {
        navigate('/');
      }, 1200);
    } catch (e: any) {
      setError(e.message || 'Erreur lors de la modification de l\'identifiant.');
    } finally {
      setLoading(false);
    }
  };

  if (!credential) {
    return (
      <View style={styles.pageContainer}>
        <Text style={styles.errorText}>Identifiant non trouvé</Text>
      </View>
    );
  }

  return (
    <View style={styles.pageContainer}>
      {error && <ErrorBanner message={error} />}
      <Toast message={toast} />
      <View style={styles.pageContent}>
        <View style={styles.pageHeader}>
          <Pressable style={styles.backBtn} onPress={() => navigate('/')} accessibilityLabel="Retour">
            <Text style={styles.backBtnText}>←</Text>
          </Pressable>
          <Text style={styles.detailsTitle}>Modifier l'identifiant</Text>
        </View>
        <View style={styles.formContainer}>
          <Input
            label="Nom de l'identifiant"
            id="title"
            type="text"
            value={title}
            onChange={setTitle}
            placeholder="[credentialsTitle]"
            required
          />
          <Input
            label="Email / Nom d'utilisateur"
            id="username"
            type="email"
            value={username}
            onChange={setUsername}
            placeholder="[userEmail]"
            autoComplete="email"
            required
          />
          <Input
            label="Mot de passe"
            id="password"
            type="password"
            value={password}
            onChange={setPassword}
            placeholder="Entrez un mot de passe..."
            required
          />
          <Input
            label="Lien"
            id="url"
            type="text"
            value={url}
            onChange={setUrl}
            placeholder="[credentialUrl]"
          />
          <Input
            label="Note"
            id="note"
            type="text"
            value={note}
            onChange={setNote}
            placeholder="Entrez une note..."
          />
          <Pressable
            style={[styles.btn, styles.btnPrimary, styles.fullWidth, loading ? styles.btnDisabled : null]}
            onPress={handleSubmit}
            disabled={loading}
            accessibilityRole="button"
          >
            <Text style={styles.btnText}>Modifier</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    padding: spacing.md,
  },
  pageContent: {
    flex: 1,
  },
  pageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  backBtn: {
    marginRight: spacing.sm,
    padding: spacing.xs,
  },
  backBtnText: {
    fontSize: 28,
    color: colors.primary,
  },
  detailsTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600',
    color: colors.primary,
  },
  formContainer: {
    flex: 1,
  },
  errorText: {
    fontSize: typography.fontSize.md,
    color: colors.error,
    textAlign: 'center',
    marginTop: spacing.xl,
  },
  btn: {
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
  },
  btnDisabled: {
    backgroundColor: colors.disabled,
  },
  fullWidth: {
    width: '100%',
  },
  btnText: {
    color: colors.white,
    fontSize: typography.fontSize.md,
    fontWeight: '600',
  },
}); 