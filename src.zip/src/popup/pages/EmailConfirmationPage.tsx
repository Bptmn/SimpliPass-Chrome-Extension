import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';
import { ErrorBanner } from '../components/ErrorBanner';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

interface EmailConfirmationPageProps {
  email: string;
  onConfirm: (code: string) => void;
  onResend: () => void;
}

export const EmailConfirmationPage: React.FC<EmailConfirmationPageProps> = ({
  email,
  onConfirm,
  onResend,
}) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = () => {
    if (!code.trim()) {
      setError('Veuillez entrer le code de confirmation.');
      return;
    }
    setError(null);
    onConfirm(code);
  };

  return (
    <View style={styles.pageContainer}>
      {error && <ErrorBanner message={error} />}
      <View style={styles.pageContent}>
        <View style={styles.confirmationForm}>
          <View style={styles.formHeader}>
            <Text style={styles.confirmationTitle}>Confirmation par email</Text>
            <Text style={styles.confirmationSubtitle}>
              Nous avons envoyé un code de confirmation à {email}
            </Text>
          </View>
          <View style={styles.formSection}>
            <Text style={styles.inputLabel}>Code de confirmation</Text>
            <TextInput
              style={styles.confirmationInput}
              placeholder="Entrez le code..."
              value={code}
              onChangeText={setCode}
              keyboardType="numeric"
              maxLength={6}
              accessibilityLabel="Code de confirmation"
            />
          </View>
          <View style={styles.btnList}>
            <Pressable
              style={[styles.btn, styles.btnPrimary, styles.confirmBtn]}
              onPress={handleSubmit}
              accessibilityRole="button"
            >
              <Text style={styles.btnText}>Confirmer</Text>
            </Pressable>
            <Pressable
              style={[styles.btn, styles.btnSecondary, styles.resendBtn]}
              onPress={onResend}
              accessibilityRole="button"
            >
              <Text style={styles.btnText}>Renvoyer le code</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    padding: spacing.md,
  },
  pageContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  confirmationForm: {
    width: '100%',
    maxWidth: 360,
  },
  formHeader: {
    marginBottom: spacing.lg,
    alignItems: 'center',
  },
  confirmationTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600',
    color: colors.primary,
    marginBottom: spacing.sm,
  },
  confirmationSubtitle: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    textAlign: 'center',
  },
  formSection: {
    marginBottom: spacing.lg,
  },
  inputLabel: {
    fontSize: typography.fontSize.md,
    color: colors.primary,
    fontWeight: '500',
    marginBottom: spacing.xs,
  },
  confirmationInput: {
    width: '100%',
    height: 48,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    fontSize: typography.fontSize.md,
    color: colors.text,
    backgroundColor: layout.primaryBackground,
    textAlign: 'center',
    letterSpacing: 8,
  },
  btnList: {
    flexDirection: 'column',
  },
  btn: {
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    marginBottom: spacing.sm,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
  },
  btnSecondary: {
    backgroundColor: colors.secondary,
  },
  confirmBtn: {
    marginBottom: spacing.sm,
  },
  resendBtn: {
    marginBottom: 0,
  },
  btnText: {
    color: colors.white,
    fontSize: typography.fontSize.md,
    fontWeight: '600',
  },
});
