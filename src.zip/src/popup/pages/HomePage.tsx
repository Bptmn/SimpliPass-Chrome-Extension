import React, { useEffect, useState, useCallback } from 'react';
import { useUser } from 'hooks/useUser';
import { auth } from 'services/firebase';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';

import { CredentialDetailsPage } from './CredentialDetailsPage';
import {
  getAllCredentialsFromVaultDbWithFallback,
  getCredentialsByDomainFromVaultDb,
  getCredentialFromVaultDb,
  refreshCredentialsInVaultDb,
} from 'logic/items';
import {
  CredentialFromVaultDb,
  PageState,
  CredentialMeta,
  HomePageProps,
  CredentialDecrypted,
} from 'types/types';
import { decryptData } from 'utils/crypto';
import { getUserSecretKey } from 'logic/user';
import { CredentialCard } from '../components/CredentialCard';
import { ErrorBanner } from '../components/ErrorBanner';
import { Icon } from '../components/Icon';
import SkeletonCard from '../components/SkeletonCard';
import Toast, { useToast } from '../components/Toast';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

/**
 * Custom hook to debounce a value by a given delay.
 * Used for search input to avoid filtering on every keystroke.
 */
function useDebouncedValue<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debounced;
}

/**
 * HomePage component displays the main vault UI:
 * - Shows all credentials and domain suggestions
 * - Handles search, error, and loading states
 * - Handles credential decryption and detail view
 */
export const HomePage: React.FC<HomePageProps> = ({
  user: _userProp, // ignore this prop, use context
  pageState,
  suggestions,
  onInjectCredential,
}) => {
  const user = useUser();
  // State for all credentials, domain suggestions, search filter, selected credential, error, and loading
  const [allCreds, setAllCreds] = useState<CredentialFromVaultDb[]>([]);
  const [domainSuggestions, setDomainSuggestions] = useState<CredentialFromVaultDb[]>([]);
  const [filter, setFilter] = useState('');
  const [selected, setSelected] = useState<CredentialDecrypted | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast, showToast } = useToast();
  const debouncedFilter = useDebouncedValue(filter, 250);

  /**
   * Fetch all cached credentials for the current user on mount or when user changes.
   * Clears the cache and loads fresh credentials.
   */
  useEffect(() => {
    if (!user) return;
    setLoading(true);
    (async () => {
      try {
        const creds = await getAllCredentialsFromVaultDbWithFallback(auth.currentUser);
        setAllCreds(creds);
      } catch (e) {
        setError('Erreur lors du chargement des identifiants.');
      } finally {
        setLoading(false);
      }
    })();
  }, [user]);

  /**
   * When the pageState (domain) changes, fetch domain-matching suggestions.
   */
  useEffect(() => {
    (async () => {
      if (!pageState?.domain || !user) {
        setDomainSuggestions([]);
        return;
      }
      try {
        const suggestions = await getCredentialsByDomainFromVaultDb(pageState.domain);
        setDomainSuggestions(suggestions);
      } catch (error) {
        setError('Erreur lors de la récupération des suggestions.');
        setDomainSuggestions([]);
      }
    })();
  }, [pageState?.domain, user]);

  // Filter credentials by search input (debounced)
  const filtered = allCreds.filter((cred) =>
    cred.title?.toLowerCase().includes(debouncedFilter.toLowerCase()),
  );

  /**
   * Handles click on a credential card:
   * - Decrypts the credential and shows the detail page
   */
  const handleCardClick = async (cred: CredentialFromVaultDb) => {
    try {
      const userSecretKey = await getUserSecretKey();
      if (!userSecretKey) throw new Error('User secret key not found');
      const itemKey = await decryptData(userSecretKey, cred.itemKeyCipher);
      const password = await decryptData(itemKey, cred.passwordCipher);
      const decrypted: CredentialDecrypted = {
        createdDateTime: new Date(),
        lastUseDateTime: new Date(),
        title: cred.title,
        username: cred.username,
        password,
        note: cred.note || '',
        url: cred.url,
        itemKey,
        document_reference: {} as any,
      };
      setSelected(decrypted);
    } catch (e) {
      setError("Erreur lors du déchiffrement de l'identifiant.");
    }
  };

  // If a credential is selected, show the detail page
  if (selected) {
    return <CredentialDetailsPage credential={selected} onBack={() => setSelected(null)} />;
  }

  if (user === null) {
    return (
      <View style={styles.pageContainer}>
        <Text style={styles.loadingSpinner}>Chargement du profil utilisateur...</Text>
      </View>
    );
  }

  // Main render: search, suggestions, all credentials, error, toast
  return (
    <View style={styles.pageContainer}>
      {/* Error banner if any error occurs */}
      {error && <ErrorBanner message={error} />}
      {/* Toast notification for copy actions */}
      <Toast message={toast} />
      <View style={styles.homeContent}>
        {/* Search bar for filtering credentials */}
        <View style={styles.searchBar}>
          <View style={styles.searchBarIcon}>
            <Icon name="search" size={25} color={colors.secondary} />
          </View>
          <TextInput
            style={styles.searchInput}
            placeholder="Recherche..."
            value={filter}
            onChangeText={setFilter}
            accessibilityLabel="Search credentials"
          />
        </View>

        {/* Suggestions for the current domain */}
        <View style={styles.pageSection}>
          <Text style={styles.sectionTitle}>Suggestions</Text>
          <View style={styles.suggestionList}>
            {loading ? (
              <Text style={styles.emptyState}>Aucune suggestion pour cette page.</Text>
            ) : domainSuggestions.length === 0 ? (
              <Text style={styles.emptyState}>Aucune suggestion pour cette page.</Text>
            ) : (
              domainSuggestions.map((suggestion) => (
                <Pressable
                  key={suggestion.id}
                  onPress={() => handleCardClick(suggestion)}
                  accessibilityLabel={`Use credential for ${suggestion.title} (${suggestion.username})`}
                >
                  <CredentialCard
                    cred={suggestion}
                    hideCopyBtn={false}
                    onCopy={() => showToast('Mot de passe copié !')}
                  />
                </Pressable>
              ))
            )}
          </View>
        </View>

        {/* All credentials section */}
        <View style={styles.pageSection}>
          <Text style={styles.sectionTitle}>Tous les identifiants</Text>
          <View style={styles.credentialList}>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => <SkeletonCard key={i} />)
            ) : filtered.length === 0 ? (
              <Text style={styles.emptyState}>Aucun identifiant trouvé.</Text>
            ) : (
              filtered.map((cred) => (
                <Pressable key={cred.id} onPress={() => handleCardClick(cred)}>
                  <CredentialCard cred={cred} onCopy={() => showToast('Mot de passe copié !')} />
                </Pressable>
              ))
            )}
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    padding: spacing.md,
  },
  homeContent: {
    flexDirection: 'column',
    marginBottom: spacing.sm,
  },
  searchBar: {
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  searchBarIcon: {
    position: 'absolute',
    left: spacing.sm,
    zIndex: 1,
  },
  searchInput: {
    width: '100%',
    height: 42,
    borderRadius: 20,
    backgroundColor: layout.secondaryBackground,
    borderWidth: 0,
    paddingHorizontal: spacing.lg,
    paddingLeft: spacing.xl + spacing.sm,
    fontSize: typography.fontSize.sm,
    color: colors.text,
  },
  pageSection: {
    marginBottom: spacing.sm,
  },
  sectionTitle: {
    fontSize: typography.fontSize.md,
    fontWeight: '600',
    color: colors.primary,
    marginBottom: spacing.sm,
  },
  suggestionList: {
    flexDirection: 'column',
    marginBottom: spacing.xs,
  },
  credentialList: {
    flexDirection: 'column',
    width: '100%',
  },
  emptyState: {
    textAlign: 'center',
    color: colors.textSecondary,
    fontSize: typography.fontSize.sm,
    fontStyle: 'italic',
    padding: spacing.lg,
  },
  loadingSpinner: {
    margin: spacing.lg,
    textAlign: 'center',
    fontSize: typography.fontSize.md,
    color: colors.secondary,
  },
});
