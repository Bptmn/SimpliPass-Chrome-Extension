// SettingsPage.tsx
// This page displays the user's profile and settings.
// It also allows the user to logout.

import React, { useState, Suspense } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useUser } from 'hooks/useUser';
import { logoutUser } from 'logic/user';
import { ErrorBanner } from '../components/ErrorBanner';
import { Icon } from '../components/Icon';
import { Toast, useToast } from '../components/Toast';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

const SettingsPage: React.FC = () => {
  const user = useUser();
  const [error, setError] = useState<string | null>(null);
  const { toast, showToast } = useToast();

  const handleLogout = async () => {
    try {
      await logoutUser();
      showToast('Déconnexion réussie');
      setTimeout(() => window.location.reload(), 1200);
    } catch (e) {
      setError('Erreur lors de la déconnexion.');
    }
  };

  // Lazy load non-critical sections (simulate for demo)
  const LazyMenu = React.lazy(() =>
    Promise.resolve({
      default: () => (
        <View style={styles.menuList}>
          <Pressable style={styles.menuItem} accessibilityLabel="Sécurité">
            <View style={styles.menuIcon}>
              <Icon name="security" size={22} color={colors.secondary} />
            </View>
            <Text style={styles.menuLabel}>Sécurité</Text>
            <View style={styles.menuArrow}>
              <Icon name="arrowForward" size={15} color={colors.primary} />
            </View>
          </Pressable>
          <Pressable style={styles.menuItem} accessibilityLabel="Aide">
            <View style={styles.menuIcon}>
              <Icon name="help" size={22} color={colors.secondary} />
            </View>
            <Text style={styles.menuLabel}>Aide</Text>
            <View style={styles.menuArrow}>
              <Icon name="arrowForward" size={15} color={colors.primary} />
            </View>
          </Pressable>
          <Pressable style={styles.menuItem} accessibilityLabel="Mon abonnement">
            <View style={styles.menuIcon}>
              <Icon name="workspacePremium" size={22} color={colors.secondary} />
            </View>
            <Text style={styles.menuLabel}>Mon abonnement</Text>
            <View style={styles.menuArrow}>
              <Icon name="arrowForward" size={15} color={colors.primary} />
            </View>
          </Pressable>
          <Pressable style={styles.menuItem} accessibilityLabel="Languages">
            <View style={styles.menuIcon}>
              <Icon name="language" size={22} color={colors.secondary} />
            </View>
            <Text style={styles.menuLabel}>Languages</Text>
            <View style={styles.menuArrow}>
              <Icon name="arrowForward" size={15} color={colors.primary} />
            </View>
          </Pressable>
        </View>
      ),
    }),
  );

  return (
    <View style={styles.pageContainer}>
      {error && <ErrorBanner message={error} />}
      <Toast message={toast} />
      <View style={styles.pageContent}>
        <View style={styles.pageSection}>
          <View style={styles.profileCard}>
            <View style={styles.userDetails}>
              <View style={styles.userIcon}>
                <Icon name="person" size={25} color={colors.secondary} />
              </View>
              <Text style={styles.userEmail}>{user ? user.email : 'Non connecté'}</Text>
            </View>
            <View style={styles.userDetails}>
              <Text style={styles.userSubscriptionTitle}>Abonnement :</Text>
              <Text style={styles.userSubscriptionValue}> Basic</Text>
            </View>
          </View>
        </View>
        <View style={styles.pageSection}>
          <Suspense fallback={<Text>Chargement…</Text>}>
            <LazyMenu />
          </Suspense>
        </View>
        <View style={styles.btnList}>
          <Pressable
            style={[styles.btn, styles.btnSecondary, styles.feedbackBtn]}
            accessibilityLabel="Donnez votre avis"
          >
            <Text style={styles.btnText}>Donnez votre avis</Text>
          </Pressable>
          <Pressable
            style={[styles.btn, styles.btnPrimary, styles.logoutBtn]}
            onPress={handleLogout}
            accessibilityLabel="Se déconnecter"
            accessibilityRole="button"
          >
            <Text style={styles.btnText}>Se déconnecter</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    padding: spacing.md,
  },
  pageContent: {
    flex: 1,
  },
  pageSection: {
    marginBottom: spacing.md,
  },
  profileCard: {
    padding: spacing.sm,
    backgroundColor: layout.secondaryBackground,
    borderRadius: radius.md,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  userDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  userIcon: {
    fontSize: 24,
    color: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: layout.secondaryBackground,
    borderRadius: 25,
    width: 50,
    height: 50,
    marginRight: spacing.sm,
  },
  userEmail: {
    fontSize: typography.fontSize.md,
    color: colors.primary,
    fontWeight: '500',
  },
  userSubscriptionTitle: {
    fontSize: typography.fontSize.sm,
    color: colors.secondary,
    fontWeight: '500',
  },
  userSubscriptionValue: {
    fontSize: typography.fontSize.sm,
    color: colors.primary,
    fontWeight: '500',
  },
  menuList: {
    flexDirection: 'column',
    marginBottom: spacing.sm,
    padding: spacing.sm,
    borderRadius: radius.md,
    backgroundColor: layout.secondaryBackground,
  },
  menuItem: {
    height: 35,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginBottom: spacing.sm,
    borderWidth: 0,
    textAlign: 'left',
    width: '100%',
    outline: 'none',
    position: 'relative',
  },
  menuIcon: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  menuLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.primary,
    flex: 1,
    fontWeight: '400',
  },
  menuArrow: {
    // Color will be applied to the Icon component
  },
  btnList: {
    marginTop: spacing.sm,
  },
  btn: {
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
    marginBottom: spacing.xs,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
  },
  btnSecondary: {
    backgroundColor: colors.secondary,
  },
  feedbackBtn: {
    marginBottom: spacing.xs,
  },
  logoutBtn: {
    marginBottom: 0,
  },
  btnText: {
    color: colors.white,
    fontSize: typography.fontSize.md,
    fontWeight: '600',
  },
});

export default SettingsPage;
