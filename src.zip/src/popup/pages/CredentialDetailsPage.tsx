import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { CredentialDecrypted } from 'types/types';
import { deleteCredential, updateCredential } from 'logic/items';
import { ErrorBanner } from '../components/ErrorBanner';
import { Icon } from '../components/Icon';
import { Toast, useToast } from '../components/Toast';
import { colors } from '../../design/colors';
import { spacing } from '../../design/spacing';
import { typography } from '../../design/typography';
import { radius } from '../../design/radius';
import { layout } from '../../design/layout';

interface CredentialDetailsPageProps {
  credential: CredentialDecrypted;
  onBack: () => void;
}

export const CredentialDetailsPage: React.FC<CredentialDetailsPageProps> = ({
  credential,
  onBack,
}) => {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const { toast, showToast } = useToast();

  const handleCopy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      showToast(`${label} copié !`);
    } catch (e) {
      setError('Erreur lors de la copie.');
    }
  };

  const handleDelete = async () => {
    try {
      await deleteCredential(credential.title);
      showToast('Identifiant supprimé');
      setTimeout(() => {
        onBack();
      }, 1200);
    } catch (e) {
      setError('Erreur lors de la suppression.');
    }
  };

  const handleEdit = () => {
    navigate('/modify', { state: { credential } });
  };

  return (
    <View style={styles.pageContainer}>
      {error && <ErrorBanner message={error} />}
      <Toast message={toast} />
      <View style={styles.pageContent}>
        <View style={styles.pageHeader}>
          <Pressable style={styles.backBtn} onPress={onBack} accessibilityLabel="Retour">
            <Text style={styles.backBtnText}>←</Text>
          </Pressable>
          <Text style={styles.detailsTitle}>Détails de l'identifiant</Text>
        </View>

        <View style={styles.detailsCard}>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Nom de l'identifiant</Text>
            <View style={styles.detailValueContainer}>
              <Text style={styles.detailValue}>{credential.title}</Text>
              <Pressable
                style={styles.copyBtn}
                onPress={() => handleCopy(credential.title, 'Nom')}
                accessibilityLabel="Copier le nom"
              >
                <Text style={styles.copyIcon}>📋</Text>
              </Pressable>
            </View>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Email / Nom d'utilisateur</Text>
            <View style={styles.detailValueContainer}>
              <Text style={styles.detailValue}>{credential.username}</Text>
              <Pressable
                style={styles.copyBtn}
                onPress={() => handleCopy(credential.username, 'Nom d\'utilisateur')}
                accessibilityLabel="Copier le nom d'utilisateur"
              >
                <Text style={styles.copyIcon}>📋</Text>
              </Pressable>
            </View>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Mot de passe</Text>
            <View style={styles.detailValueContainer}>
              <Text style={styles.detailValue}>••••••••</Text>
              <Pressable
                style={styles.copyBtn}
                onPress={() => handleCopy(credential.password, 'Mot de passe')}
                accessibilityLabel="Copier le mot de passe"
              >
                <Text style={styles.copyIcon}>📋</Text>
              </Pressable>
            </View>
          </View>

          {credential.url && (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Lien</Text>
              <View style={styles.detailValueContainer}>
                <Text style={styles.detailValue}>{credential.url}</Text>
                <Pressable
                  style={styles.copyBtn}
                  onPress={() => handleCopy(credential.url, 'Lien')}
                  accessibilityLabel="Copier le lien"
                >
                  <Text style={styles.copyIcon}>📋</Text>
                </Pressable>
              </View>
            </View>
          )}

          {credential.note && (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Note</Text>
              <View style={styles.detailValueContainer}>
                <Text style={styles.detailValue}>{credential.note}</Text>
                <Pressable
                  style={styles.copyBtn}
                  onPress={() => handleCopy(credential.note, 'Note')}
                  accessibilityLabel="Copier la note"
                >
                  <Text style={styles.copyIcon}>📋</Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>

        <View style={styles.actionButtons}>
          <Pressable
            style={[styles.btn, styles.btnPrimary, styles.editBtn]}
            onPress={handleEdit}
            accessibilityRole="button"
          >
            <Text style={styles.btnText}>Modifier</Text>
          </Pressable>
          <Pressable
            style={[styles.btn, styles.btnSecondary, styles.deleteBtn]}
            onPress={handleDelete}
            accessibilityRole="button"
          >
            <Text style={styles.btnText}>Supprimer</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  pageContainer: {
    flex: 1,
    backgroundColor: layout.primaryBackground,
    padding: spacing.md,
  },
  pageContent: {
    flex: 1,
  },
  pageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.lg,
  },
  backBtn: {
    marginRight: spacing.sm,
    padding: spacing.xs,
  },
  backBtnText: {
    fontSize: 28,
    color: colors.primary,
  },
  detailsTitle: {
    fontSize: typography.fontSize.lg,
    fontWeight: '600',
    color: colors.primary,
  },
  detailsCard: {
    backgroundColor: layout.secondaryBackground,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.lg,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  detailRow: {
    flexDirection: 'column',
    marginBottom: spacing.md,
  },
  detailLabel: {
    fontSize: typography.fontSize.sm,
    color: colors.textSecondary,
    fontWeight: '500',
    marginBottom: spacing.xs,
  },
  detailValueContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  detailValue: {
    flex: 1,
    fontSize: typography.fontSize.md,
    color: colors.text,
    fontWeight: '500',
  },
  copyBtn: {
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.secondary,
    borderRadius: radius.sm,
    marginLeft: spacing.sm,
  },
  copyIcon: {
    fontSize: 16,
    color: colors.white,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  btn: {
    flex: 1,
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 48,
  },
  btnPrimary: {
    backgroundColor: colors.primary,
    marginRight: spacing.xs,
  },
  btnSecondary: {
    backgroundColor: colors.error,
    marginLeft: spacing.xs,
  },
  editBtn: {
    marginRight: spacing.xs,
  },
  deleteBtn: {
    marginLeft: spacing.xs,
  },
  btnText: {
    color: colors.white,
    fontSize: typography.fontSize.md,
    fontWeight: '600',
  },
});
