export declare const cognitoConfig: {
  userPoolId: string;
  userPoolClientId: string;
  region: string;
};
