import { config } from './config';

export const cognitoConfig = config.Cognito;
